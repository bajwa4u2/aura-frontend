import 'dart:ui_web' as ui;

import 'package:flutter/material.dart';
import 'package:web/web.dart' as web;

class PdfViewer extends StatefulWidget {
  final String assetPath;
  final String title;

  const PdfViewer({super.key, required this.assetPath, required this.title});

  @override
  State<PdfViewer> createState() => _PdfViewerWebState();
}

class _PdfViewerWebState extends State<PdfViewer> {
  late final String _viewType;
  bool _registered = false;

  @override
  void initState() {
    super.initState();
    _viewType = 'pdf-iframe-${DateTime.now().microsecondsSinceEpoch}';
    _register();
  }

  void _register() {
    if (_registered) return;

    final fileName = widget.assetPath.split('/').last;
    final src = '/$fileName';

    ui.platformViewRegistry.registerViewFactory(_viewType, (int viewId) {
      final iframe = web.HTMLIFrameElement()
        ..src = src
        ..style.border = '0'
        ..style.width = '100%'
        ..style.height = '100%'
        ..allowFullscreen = true;

      return iframe;
    });

    _registered = true;
  }

  @override
  Widget build(BuildContext context) {
    return HtmlElementView(viewType: _viewType);
  }
}
