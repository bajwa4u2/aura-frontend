import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/ui/aura_design_system.dart';
import '../../../core/ui/aura_platform_components.dart';
import '../../../core/ui/aura_radius.dart';
import '../../../core/ui/aura_scaffold.dart';
import '../../../core/ui/aura_space.dart';
import '../../../core/ui/aura_surface.dart';
import '../../../core/ui/aura_text.dart';
import '../../feed/domain/post.dart';
import '../../feed/providers.dart';

Map<String, dynamic> _asMap(dynamic v) {
  if (v is Map<String, dynamic>) return v;
  if (v is Map) return Map<String, dynamic>.from(v);
  return <String, dynamic>{};
}

class PublicHomeScreen extends ConsumerWidget {
  const PublicHomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final worksAsync = ref.watch(feedProvider);

    return AuraScaffold(
      showHeader: false,
      body: ListView(
        padding: EdgeInsets.zero,
        children: [
          _HeroSection(
            onJoin: () => context.go('/register'),
            onExplore: () => context.go('/search'),
            onInstitutions: () => context.go('/institutions'),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(
              AuraSpace.s16,
              AuraSpace.s28,
              AuraSpace.s16,
              AuraSpace.s32,
            ),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 1160),
                child: _PublicFeedSection(
                  worksAsync: worksAsync,
                  onExplore: () => context.go('/search'),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// HERO
// ─────────────────────────────────────────────────────────────────────────────

class _HeroSection extends StatelessWidget {
  const _HeroSection({
    required this.onJoin,
    required this.onExplore,
    required this.onInstitutions,
  });

  final VoidCallback onJoin;
  final VoidCallback onExplore;
  final VoidCallback onInstitutions;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        gradient: AuraGradients.hero,
        border: Border(bottom: BorderSide(color: AuraSurface.divider)),
      ),
      child: Stack(
        children: [
          // Subtle accent radial glow behind headline
          Positioned(
            top: -60,
            left: -80,
            child: Container(
              width: 480,
              height: 480,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [Color(0x1A5B6CFF), Colors.transparent],
                  radius: 0.65,
                ),
              ),
            ),
          ),
          Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 1160),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(
                  AuraSpace.s20,
                  60,
                  AuraSpace.s20,
                  56,
                ),
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final wide = constraints.maxWidth >= 720;
                    return wide
                        ? Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Expanded(
                                flex: 5,
                                child: _HeroLeft(
                                  onJoin: onJoin,
                                  onExplore: onExplore,
                                ),
                              ),
                              const SizedBox(width: AuraSpace.s32),
                              Expanded(
                                flex: 3,
                                child: _HeroPlatformCard(
                                  onInstitutions: onInstitutions,
                                ),
                              ),
                            ],
                          )
                        : Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _HeroLeft(onJoin: onJoin, onExplore: onExplore),
                              const SizedBox(height: AuraSpace.s24),
                              _HeroPlatformCard(onInstitutions: onInstitutions),
                            ],
                          );
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _HeroLeft extends StatelessWidget {
  const _HeroLeft({required this.onJoin, required this.onExplore});

  final VoidCallback onJoin;
  final VoidCallback onExplore;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Eyebrow label
        Container(
          padding: const EdgeInsets.symmetric(
            horizontal: AuraSpace.s10,
            vertical: AuraSpace.s6,
          ),
          decoration: BoxDecoration(
            color: AuraSurface.accentSoft,
            borderRadius: BorderRadius.circular(AuraRadius.pill),
            border: Border.all(
              color: AuraSurface.accent.withValues(alpha: 0.3),
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.auto_awesome_rounded,
                size: 11,
                color: AuraSurface.accentText,
              ),
              const SizedBox(width: AuraSpace.s6),
              Text(
                'Civic communication platform',
                style: AuraText.label.copyWith(color: AuraSurface.accentText),
              ),
            ],
          ),
        ),
        const SizedBox(height: AuraSpace.s20),

        // Display headline
        const Text(
          'Work that earns\nreal consideration',
          style: AuraText.display,
        ),
        const SizedBox(height: AuraSpace.s16),

        // Sub-headline
        Text(
          'Publish writing, share creations, and build a public record that institutions and people take seriously — with no noise.',
          style: AuraText.body.copyWith(color: AuraSurface.muted, height: 1.6),
        ),
        const SizedBox(height: AuraSpace.s28),

        // CTAs
        Wrap(
          spacing: AuraSpace.s10,
          runSpacing: AuraSpace.s10,
          children: [
            AuraPrimaryButton(
              label: 'Join Aura',
              onPressed: onJoin,
              icon: Icons.arrow_forward_rounded,
            ),
            _HeroOutlineButton(label: 'Explore work', onTap: onExplore),
          ],
        ),
        const SizedBox(height: AuraSpace.s20),

        // Trust pills
        const Wrap(
          spacing: AuraSpace.s8,
          runSpacing: AuraSpace.s8,
          children: [
            _TrustPill(
              label: 'Verified identities',
              icon: Icons.verified_user_outlined,
            ),
            _TrustPill(
              label: 'Institution ready',
              icon: Icons.apartment_outlined,
            ),
            _TrustPill(label: 'No noise', icon: Icons.block_flipped),
          ],
        ),
      ],
    );
  }
}

class _HeroPlatformCard extends StatelessWidget {
  const _HeroPlatformCard({required this.onInstitutions});

  final VoidCallback onInstitutions;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AuraSpace.s20),
      decoration: BoxDecoration(
        color: AuraSurface.card,
        borderRadius: BorderRadius.circular(AuraRadius.xl),
        border: Border.all(color: AuraSurface.divider),
        boxShadow: AuraShadows.panel,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Platform overview',
            style: AuraText.label.copyWith(
              color: AuraSurface.faint,
              letterSpacing: 0.8,
            ),
          ),
          const SizedBox(height: AuraSpace.s16),
          const _FeatureRow(
            icon: Icons.edit_note_rounded,
            title: 'Publish works',
            body: 'Writing, media, and long-form content with full provenance.',
          ),
          const SizedBox(height: AuraSpace.s12),
          const Divider(color: AuraSurface.divider, height: 1),
          const SizedBox(height: AuraSpace.s12),
          const _FeatureRow(
            icon: Icons.apartment_rounded,
            title: 'Institutional trust',
            body: 'Verified institutions that signal professional context.',
          ),
          const SizedBox(height: AuraSpace.s12),
          const Divider(color: AuraSurface.divider, height: 1),
          const SizedBox(height: AuraSpace.s12),
          const _FeatureRow(
            icon: Icons.mail_outline_rounded,
            title: 'Direct correspondence',
            body: 'Private, structured messaging for serious communication.',
          ),
          const SizedBox(height: AuraSpace.s20),
          MouseRegion(
            cursor: SystemMouseCursors.click,
            child: GestureDetector(
              onTap: onInstitutions,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Browse institutions',
                    style: AuraText.small.copyWith(
                      color: AuraSurface.accentText,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(width: AuraSpace.s6),
                  const Icon(
                    Icons.arrow_forward_rounded,
                    size: 14,
                    color: AuraSurface.accentText,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _FeatureRow extends StatelessWidget {
  const _FeatureRow({
    required this.icon,
    required this.title,
    required this.body,
  });

  final IconData icon;
  final String title;
  final String body;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 34,
          height: 34,
          decoration: BoxDecoration(
            color: AuraSurface.accentSoft,
            borderRadius: BorderRadius.circular(AuraRadius.r10),
            border: Border.all(
              color: AuraSurface.accent.withValues(alpha: 0.2),
            ),
          ),
          child: Icon(
            icon,
            size: AuraIconSize.sm,
            color: AuraSurface.accentText,
          ),
        ),
        const SizedBox(width: AuraSpace.s12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: AuraText.small.copyWith(
                  fontWeight: FontWeight.w700,
                  color: AuraSurface.ink,
                ),
              ),
              const SizedBox(height: AuraSpace.s2),
              Text(
                body,
                style: AuraText.small.copyWith(
                  color: AuraSurface.muted,
                  height: 1.4,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _TrustPill extends StatelessWidget {
  const _TrustPill({required this.label, required this.icon});

  final String label;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AuraSpace.s10,
        vertical: AuraSpace.s6,
      ),
      decoration: BoxDecoration(
        color: AuraSurface.subtle,
        borderRadius: BorderRadius.circular(AuraRadius.pill),
        border: Border.all(color: AuraSurface.divider),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: AuraSurface.faint),
          const SizedBox(width: AuraSpace.s6),
          Text(
            label,
            style: AuraText.micro.copyWith(
              color: AuraSurface.muted,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class _HeroOutlineButton extends StatelessWidget {
  const _HeroOutlineButton({required this.label, required this.onTap});

  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AuraRadius.r14),
        child: Container(
          padding: const EdgeInsets.symmetric(
            horizontal: AuraSpace.s20,
            vertical: AuraSpace.s12,
          ),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AuraRadius.r14),
            border: Border.all(color: AuraSurface.divider),
          ),
          child: Text(
            label,
            style: AuraText.body.copyWith(fontWeight: FontWeight.w600),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PUBLIC FEED SECTION
// ─────────────────────────────────────────────────────────────────────────────

class _PublicFeedSection extends StatelessWidget {
  const _PublicFeedSection({required this.worksAsync, required this.onExplore});

  final AsyncValue<List<Post>> worksAsync;
  final VoidCallback onExplore;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Public work', style: AuraText.headline),
                  SizedBox(height: AuraSpace.s4),
                  Text(
                    'Recent writing and creations from the network.',
                    style: AuraText.muted,
                  ),
                ],
              ),
            ),
            AuraGhostButton(
              label: 'Explore all',
              onPressed: onExplore,
              icon: Icons.explore_outlined,
            ),
          ],
        ),
        const SizedBox(height: AuraSpace.s20),
        worksAsync.when(
          data: (posts) {
            if (posts.isEmpty) {
              return const AuraEmptyState(
                title: 'No public work yet',
                body: 'When people publish, their work will appear here.',
                icon: Icons.public_outlined,
              );
            }
            return Column(
              children: [
                for (final p in posts.take(6)) ...[
                  _PublicPostCard(post: p),
                  const SizedBox(height: AuraSpace.s10),
                ],
                const SizedBox(height: AuraSpace.s6),
                Align(
                  alignment: Alignment.centerLeft,
                  child: AuraSecondaryButton(
                    label: 'Explore more work',
                    onPressed: onExplore,
                    icon: Icons.explore_outlined,
                  ),
                ),
              ],
            );
          },
          loading: () =>
              const AuraLoadingState(message: 'Loading public work…'),
          error: (e, _) => const AuraErrorState(
            title: 'Could not load public work',
            body: 'Refresh the page or try again in a moment.',
          ),
        ),
      ],
    );
  }
}

class _PublicPostCard extends StatelessWidget {
  const _PublicPostCard({required this.post});

  final Post post;

  @override
  Widget build(BuildContext context) {
    final a = post.author;
    final aMap = _asMap(a);
    final name = ((aMap['displayName'] ?? a?.displayName ?? '') as String)
        .trim();
    final handle = ((aMap['handle'] ?? a?.handle ?? '') as String).trim();
    final byline = handle.isNotEmpty
        ? '@$handle${name.isNotEmpty ? ' · $name' : ''}'
        : name;

    final text = post.text.trim();
    final screenW = MediaQuery.of(context).size.width;
    final maxLen = screenW < 600 ? 180 : 280;
    final preview = text.length <= maxLen
        ? text
        : '${text.substring(0, maxLen).trim()}…';

    final createdAt = post.createdAt;
    final dateLabel =
        '${createdAt.year}-${createdAt.month.toString().padLeft(2, '0')}-${createdAt.day.toString().padLeft(2, '0')}';

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(AuraRadius.card),
        onTap: () => context.push('/posts/${post.id}'),
        child: Container(
          padding: const EdgeInsets.all(AuraSpace.s16),
          decoration: BoxDecoration(
            gradient: AuraGradients.card,
            borderRadius: BorderRadius.circular(AuraRadius.card),
            border: Border.all(color: AuraSurface.divider),
            boxShadow: AuraShadows.card,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Author row
              Row(
                children: [
                  AuraAvatar(name: name.isNotEmpty ? name : handle, size: 32),
                  const SizedBox(width: AuraSpace.s10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          byline.isEmpty ? 'Aura member' : byline,
                          style: AuraText.small.copyWith(
                            fontWeight: FontWeight.w700,
                            color: AuraSurface.ink,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        if (dateLabel.isNotEmpty)
                          Text(dateLabel, style: AuraText.micro),
                      ],
                    ),
                  ),
                  const Icon(
                    Icons.arrow_forward_ios_rounded,
                    size: 12,
                    color: AuraSurface.faint,
                  ),
                ],
              ),

              // Text preview
              if (preview.isNotEmpty) ...[
                const SizedBox(height: AuraSpace.s12),
                Text(
                  preview,
                  style: AuraText.body.copyWith(height: 1.5),
                  maxLines: 4,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
