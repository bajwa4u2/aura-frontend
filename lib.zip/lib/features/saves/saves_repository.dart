import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/auth/session_providers.dart';
import '../feed/domain/post.dart';


class SavesRepository {
  SavesRepository(this._ref, this._dio);

  final Ref _ref;
  final Dio _dio;

  bool _isAuthed() {
    final status = _ref.read(authStatusProvider);
    return status == AuthStatus.authed;
  }

  bool _isAuthFailure(DioException e) {
    final code = e.response?.statusCode;
    return code == 401 || code == 403;
  }

  bool _extractSaved(dynamic data) {
    if (data is bool) return data;

    if (data is Map) {
      final v1 = data['saved'];
      if (v1 is bool) return v1;

      final v2 = data['isSaved'];
      if (v2 is bool) return v2;

      final inner = data['data'];
      if (inner is Map) {
        final a = inner['saved'];
        if (a is bool) return a;

        final b = inner['isSaved'];
        if (b is bool) return b;
      }
    }

    return false;
  }

  List<Map<String, dynamic>> _extractItems(dynamic data) {
    if (data is List) {
      return data
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
    }

    if (data is Map<String, dynamic>) {
      final items = data['items'];
      if (items is List) {
        return items
            .whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList();
      }

      final directData = data['data'];
      if (directData is List) {
        return directData
            .whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList();
      }

      if (directData is Map) {
        final nestedItems = directData['items'];
        if (nestedItems is List) {
          return nestedItems
              .whereType<Map>()
              .map((e) => Map<String, dynamic>.from(e))
              .toList();
        }

        final nestedData = directData['data'];
        if (nestedData is List) {
          return nestedData
              .whereType<Map>()
              .map((e) => Map<String, dynamic>.from(e))
              .toList();
        }
      }
    }

    return <Map<String, dynamic>>[];
  }

  Future<List<Map<String, dynamic>>> _fetchSavedRaw({
    int limit = 100,
    String? cursor,
  }) async {
    if (!_isAuthed()) return <Map<String, dynamic>>[];

    try {
      final res = await _dio.get(
        '/saves/me',
        queryParameters: {
          'limit': limit,
          if (cursor != null && cursor.isNotEmpty) 'cursor': cursor,
        },
      );

      return _extractItems(res.data);
    } on DioException catch (e) {
      if (_isAuthFailure(e)) return <Map<String, dynamic>>[];
      rethrow;
    }
  }

  Future<List<Post>> listSaved({int limit = 24, String? cursor}) async {
    final items = await _fetchSavedRaw(limit: limit, cursor: cursor);

    return items
        .map((e) => e['post'])
        .whereType<Map>()
        .map((e) => Post.fromJson(Map<String, dynamic>.from(e)))
        .toList();
  }

  Future<bool> isSaved(String postId) async {
    if (!_isAuthed()) return false;

    final pid = postId.trim();
    if (pid.isEmpty) return false;

    try {
      final res = await _dio.get('/saves/for/$pid');
      return _extractSaved(res.data);
    } on DioException catch (e) {
      if (_isAuthFailure(e)) {
        return false;
      }
      rethrow;
    }
  }

  Future<bool> save(String postId) async {
    if (!_isAuthed()) return false;

    final pid = postId.trim();
    if (pid.isEmpty) return false;

    try {
      final res = await _dio.post('/saves/$pid');
      return _extractSaved(res.data);
    } on DioException catch (e) {
      if (_isAuthFailure(e)) {
        return false;
      }
      rethrow;
    }
  }

  Future<bool> unsave(String postId) async {
    if (!_isAuthed()) return false;

    final pid = postId.trim();
    if (pid.isEmpty) return false;

    try {
      final res = await _dio.delete('/saves/$pid');
      return _extractSaved(res.data);
    } on DioException catch (e) {
      if (_isAuthFailure(e)) {
        return false;
      }
      rethrow;
    }
  }

  Future<bool> toggle(String postId) async {
    final currentlySaved = await isSaved(postId);
    if (currentlySaved) {
      return unsave(postId);
    }
    return save(postId);
  }
}
